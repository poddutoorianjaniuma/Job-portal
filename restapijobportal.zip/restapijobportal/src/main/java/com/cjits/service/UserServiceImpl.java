package com.cjits.service;

import com.cjits.entity.User;
import com.cjits.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private static final Logger LOGGER = Logger.getLogger(UserServiceImpl.class.getName());

    @Autowired
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User register(User user) {
        Optional<User> existingUser = userRepository.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            throw new RuntimeException("Username already exists");
        }

        existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser.isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        return userRepository.save(user);
    }

    @Override
    public User login(String username, String password) {
        Optional<User> optionalUser = userRepository.findByUsername(username);

        if (optionalUser.isPresent()) {
            User user = optionalUser.get();

            if (!user.getPassword().equals(password)) {
                throw new RuntimeException("Invalid password");
            }

            // Additional login logic can be added here if necessary

            return user;
        } else {
            throw new RuntimeException("User not found");
        }
    }


    @Override
    public void forgotPassword(String email) {
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isPresent()) {
            String newPassword = "newPassword123"; // Generate a new password (this should ideally be a secure random password)
            user.get().setPassword(newPassword);
            userRepository.save(user.get());
            LOGGER.info("Reset password email sent with new password: " + newPassword);
        } else {
            throw new RuntimeException("User not found with email: " + email);
        }
    }

    @Override
    public void logout(String username) {
        LOGGER.info("User logged out: " + username);
    }

    @Override
    public List<User> getByRole(User.Role role) {
        List<User> users = userRepository.findByRole(role);

        if (!users.isEmpty()) {
            return users;
        } else {
            throw new RuntimeException("Users with role " + role + " not found");
        }
    }


    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long id) {
        Optional<User> user = userRepository.findById(id);
        if (user.isPresent()) {
            return user.get();
        } else {
            throw new RuntimeException("User not found with ID: " + id);
        }
    }

    @Override
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
