package com.cjits.controller;

import com.cjits.entity.Resume;
import com.cjits.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/resumes")
public class ResumeController {

    private final ResumeService resumeService;

    @Autowired
    public ResumeController(ResumeService resumeService) {
        this.resumeService = resumeService;
    }

    @PostMapping("/{userId}")
    public ResponseEntity<Resume> createResume(@RequestBody Resume resume, @PathVariable Long userId) {
        Resume savedResume = resumeService.saveResume(resume, userId);
        return new ResponseEntity<>(savedResume, HttpStatus.CREATED);
    }

    @GetMapping("/{userId}/{resumeId}")
    public ResponseEntity<Resume> getResumeById(@PathVariable Long userId, @PathVariable Long resumeId) {
        return resumeService.findResumeByUserIdAndResumeId(userId, resumeId)
                .map(resume -> new ResponseEntity<>(resume, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/skills/{skills}")
    public ResponseEntity<List<Resume>> getResumesBySkills(@PathVariable String skills) {
        List<Resume> resumes = resumeService.findResumesBySkills(skills);
        return new ResponseEntity<>(resumes, HttpStatus.OK);
    }

    @GetMapping("/qualifications/{qualifications}")
    public ResponseEntity<List<Resume>> getResumesByQualifications(@PathVariable String qualifications) {
        List<Resume> resumes = resumeService.findResumesByQualifications(qualifications);
        return new ResponseEntity<>(resumes, HttpStatus.OK);
    }

    @GetMapping("/achievements/{achievements}")
    public ResponseEntity<List<Resume>> getResumesByAchievements(@PathVariable String achievements) {
        List<Resume> resumes = resumeService.findResumesByAchievements(achievements);
        return new ResponseEntity<>(resumes, HttpStatus.OK);
    }

    @PutMapping("/{userId}/{resumeId}")
    public ResponseEntity<Resume> updateResume(@RequestBody Resume resume, @PathVariable Long userId, @PathVariable Long resumeId) {
        Resume updatedResume = resumeService.updateResume(resume, userId, resumeId);
        return new ResponseEntity<>(updatedResume, HttpStatus.OK);
    }


}
