package com.cjits.controller;

import com.cjits.entity.Experience;
import com.cjits.service.ExperienceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/experiences")
public class ExperienceController {

    private final ExperienceService experienceService;
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Autowired
    public ExperienceController(ExperienceService experienceService) {
        this.experienceService = experienceService;
    }

    @PostMapping("/{userId}")
    public ResponseEntity<Experience> createExperience(@RequestBody Experience experience, @PathVariable Long userId) {
        logger.info("Creating Experience for User ID: " + userId);
        return new ResponseEntity<>(experienceService.saveExperience(experience, userId), HttpStatus.CREATED);
    }

    @GetMapping("/company/{company}")
    public ResponseEntity<List<Experience>> getExperiencesByCompany(@PathVariable String company) {
        return new ResponseEntity<>(experienceService.findExperiencesByCompany(company), HttpStatus.OK);
    }

    @GetMapping("/designation/{designation}")
    public ResponseEntity<List<Experience>> getExperiencesByDesignation(@PathVariable String designation) {
        return new ResponseEntity<>(experienceService.findExperiencesByDesignation(designation), HttpStatus.OK);
    }



    // Additional API endpoints can be added here
}
