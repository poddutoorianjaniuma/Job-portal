
package com.cjits.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "experience")
public class Experience {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "experience_id")
    private Long experienceId;

    @ManyToOne
    @JoinColumn(name = "jobseeker_id", referencedColumnName = "user_id")
    private User jobSeeker;

    private String designation;
    private String company;
    @Temporal(TemporalType.DATE)
    private Date fromDate;
    @Temporal(TemporalType.DATE)
    private Date toDate;
    private String reasonForChange;

    // Constructors
    public Experience() {
    }

    public Experience(User jobSeeker, String designation, String company, Date fromDate, Date toDate, String reasonForChange) {
        this.jobSeeker = jobSeeker;
        this.designation = designation;
        this.company = company;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.reasonForChange = reasonForChange;
    }

    // Getters and setters
    public Long getExperienceId() {
        return experienceId;
    }

    public void setExperienceId(Long experienceId) {
        this.experienceId = experienceId;
    }

    public User getJobSeeker() {
        return jobSeeker;
    }

    public void setJobSeeker(User jobSeeker) {
        this.jobSeeker = jobSeeker;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    public String getReasonForChange() {
        return reasonForChange;
    }

    public void setReasonForChange(String reasonForChange) {
        this.reasonForChange = reasonForChange;
    }

    // toString method
    @Override
    public String toString() {
        return "Experience{" +
                "experienceId=" + experienceId +
                ", jobSeeker=" + (jobSeeker != null ? jobSeeker.getUserId() : "null") +
                ", designation='" + designation + '\'' +
                ", company='" + company + '\'' +
                ", fromDate=" + fromDate +
                ", toDate=" + toDate +
                ", reasonForChange='" + reasonForChange + '\'' +
                '}';
    }
}