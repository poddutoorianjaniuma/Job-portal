package com.cjits.service;

import com.cjits.entity.Resume;

import java.util.List;
import java.util.Optional;

public interface ResumeService {
    Resume saveResume(Resume resume, Long userId);

    Optional<Resume> findResumeByUserIdAndResumeId(Long userId, Long resumeId);

    List<Resume> findResumesBySkills(String skills);

    List<Resume> findResumesByQualifications(String qualifications);

    List<Resume> findResumesByAchievements(String achievements);

    Resume updateResume(Resume resume, Long userId, Long resumeId);


}
