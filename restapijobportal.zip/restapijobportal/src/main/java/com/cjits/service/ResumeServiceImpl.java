package com.cjits.service;

import com.cjits.entity.Resume;
import com.cjits.entity.User;
import com.cjits.repository.ResumeRepository;
import com.cjits.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ResumeServiceImpl implements ResumeService {

    private final ResumeRepository resumeRepository;
    private final UserRepository userRepository;

    @Autowired
    public ResumeServiceImpl(ResumeRepository resumeRepository, UserRepository userRepository) {
        this.resumeRepository = resumeRepository;
        this.userRepository = userRepository;
    }

    @Override
    public Resume saveResume(Resume resume, Long userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            resume.setJobSeeker(userOptional.get());
            return resumeRepository.save(resume);
        } else {
            throw new RuntimeException("User not found with ID: " + userId);
        }
    }

    @Override
    public Optional<Resume> findResumeByUserIdAndResumeId(Long userId, Long resumeId) {
        return resumeRepository.findByJobSeekerUserIdAndResumeId(userId, resumeId);
    }

    @Override
    public List<Resume> findResumesBySkills(String skills) {
        return resumeRepository.findBySkills(skills);
    }

    @Override
    public List<Resume> findResumesByQualifications(String qualifications) {
        return resumeRepository.findByQualifications(qualifications);
    }

    @Override
    public List<Resume> findResumesByAchievements(String achievements) {
        return resumeRepository.findByAchievements(achievements);
    }

    @Override
    public Resume updateResume(Resume resume, Long userId, Long resumeId) {
        Optional<Resume> existingResumeOptional = resumeRepository.findByJobSeekerUserIdAndResumeId(userId, resumeId);
        if (existingResumeOptional.isPresent()) {
            Resume existingResume = existingResumeOptional.get();
            existingResume.setQualifications(resume.getQualifications());
            existingResume.setSkills(resume.getSkills());
            existingResume.setAchievements(resume.getAchievements());
            // Set other fields if necessary
            return resumeRepository.save(existingResume);
        } else {
            throw new RuntimeException("Resume not found for User ID: " + userId + " and Resume ID: " + resumeId);
        }
    }


}
