package com.cjits.service;

import com.cjits.entity.Experience;
import com.cjits.entity.User;
import com.cjits.repository.ExperienceRepository;
import com.cjits.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ExperienceServiceImpl implements ExperienceService {

    private final ExperienceRepository experienceRepository;
    private final UserRepository userRepository;

    @Autowired
    public ExperienceServiceImpl(ExperienceRepository experienceRepository, UserRepository userRepository) {
        this.experienceRepository = experienceRepository;
        this.userRepository = userRepository;
    }

    @Override
    public Experience saveExperience(Experience experience, Long userId) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            experience.setJobSeeker(userOptional.get());
            return experienceRepository.save(experience);
        } else {
            throw new RuntimeException("User not found with ID: " + userId);
        }
    }

    @Override
    public List<Experience> findExperiencesByCompany(String company) {
        return experienceRepository.findByCompany(company);
    }

    @Override
    public List<Experience> findExperiencesByDesignation(String designation) {
        return experienceRepository.findByDesignation(designation);
    }



    // Additional methods can be implemented here
}
