package com.cjits.service;

import com.cjits.entity.Jobs;
import com.cjits.entity.User;
import com.cjits.repository.JobsRepository;
import com.cjits.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class JobsServiceImpl implements JobsService {

    private final JobsRepository jobsRepository;
    private final UserRepository userRepository;
    private static final Logger LOGGER = Logger.getLogger(JobsServiceImpl.class.getName());

    @Autowired
    public JobsServiceImpl(JobsRepository jobsRepository, UserRepository userRepository) {
        this.jobsRepository = jobsRepository;
        this.userRepository = userRepository;
    }

    @Override
    public Jobs saveJob(Jobs job, Long userId) {
        Optional<User> recruiterOptional = userRepository.findById(userId);
        if (recruiterOptional.isPresent()) {
            job.setRecruiter(recruiterOptional.get());
            return jobsRepository.save(job);
        } else {
            LOGGER.warning("User not found with ID: " + userId);
            throw new RuntimeException("User not found with ID: " + userId);
        }
    }



    @Override
    public List<Jobs> findAllJobsByRecruiterId(Long recruiterId) {
        List<Jobs> jobs = jobsRepository.findByRecruiterUserId(recruiterId);
        if (jobs.isEmpty()) {
            LOGGER.warning("No jobs found for recruiter with ID: " + recruiterId);
            throw new RuntimeException("No jobs found for recruiter with ID: " + recruiterId);
        }
        return jobs;
    }

    @Override
    public List<Jobs> findAllJobs() {
        List<Jobs> jobs = jobsRepository.findAll();
        if (jobs.isEmpty()) {
            LOGGER.warning("No jobs found");
            throw new RuntimeException("No jobs found");
        }
        return jobs;
    }

    @Override
    public List<Jobs> findJobsByTitle(String title) {
        List<Jobs> jobs = jobsRepository.findByTitle(title);
        if (jobs.isEmpty()) {
            LOGGER.warning("No jobs found with title: " + title);
            throw new RuntimeException("No jobs found with title: " + title);
        }
        return jobs;
    }

    @Override
    public List<Jobs> findJobsBySkillset(String skillset) {
        List<Jobs> jobs = jobsRepository.findBySkillset(skillset);
        if (jobs.isEmpty()) {
            LOGGER.warning("No jobs found with skillset: " + skillset);
            throw new RuntimeException("No jobs found with skillset: " + skillset);
        }
        return jobs;
    }

    @Override
    public List<Jobs> findJobsBySalary(double salary) {
        List<Jobs> jobs = jobsRepository.findBySalary(salary);
        if (jobs.isEmpty()) {
            LOGGER.warning("No jobs found with salary: " + salary);
            throw new RuntimeException("No jobs found with salary: " + salary);
        }
        return jobs;
    }

    @Override
    public List<Jobs> findJobsByCompany(String company) {
        List<Jobs> jobs = jobsRepository.findByCompany(company);
        if (jobs.isEmpty()) {
            LOGGER.warning("No jobs found with company: " + company);
            throw new RuntimeException("No jobs found with company: " + company);
        }
        return jobs;
    }

    @Override
    public List<Jobs> findJobsByLocation(String location) {
        List<Jobs> jobs = jobsRepository.findByLocation(location);
        if (jobs.isEmpty()) {
            LOGGER.warning("No jobs found with location: " + location);
            throw new RuntimeException("No jobs found with location: " + location);
        }
        return jobs;
    }
}
