package com.cjits.repository;

import com.cjits.entity.Jobs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobsRepository extends JpaRepository<Jobs, Long> {

    List<Jobs> findByJobId(Long jobId);

    List<Jobs> findByTitle(String title);
    List<Jobs> findByRecruiterUserId(Long recruiterId);

    List<Jobs> findBySkillset(String skillset);

    List<Jobs> findBySalary(double salary);

    List<Jobs> findByCompany(String company);

    List<Jobs> findByLocation(String location);
}
