package com.cjits.controller;

import com.cjits.entity.Jobs;
import com.cjits.service.JobsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/jobs")
public class JobsController {

    private final JobsService jobsService;

    @Autowired
    public JobsController(JobsService jobsService) {
        this.jobsService = jobsService;
    }

    // Save a job for a specific recruiter
    @PostMapping
    public ResponseEntity<Jobs> saveJob(@RequestBody Jobs job, @RequestParam Long userId) {
        Jobs savedJob = jobsService.saveJob(job, userId);
        return new ResponseEntity<>(savedJob, HttpStatus.CREATED);
    }



    // Find all jobs
    @GetMapping("/all")
    public ResponseEntity<List<Jobs>> findAllJobs() {
        List<Jobs> jobs = jobsService.findAllJobs();
        return new ResponseEntity<>(jobs, HttpStatus.OK);
    }

    // Find jobs by title
    @GetMapping("/title/{title}")
    public ResponseEntity<List<Jobs>> findJobsByTitle(@PathVariable String title) {
        List<Jobs> jobs = jobsService.findJobsByTitle(title);
        return new ResponseEntity<>(jobs, HttpStatus.OK);
    }

    // Find jobs by skillset
    @GetMapping("/skillset/{skillset}")
    public ResponseEntity<List<Jobs>> findJobsBySkillset(@PathVariable String skillset) {
        List<Jobs> jobs = jobsService.findJobsBySkillset(skillset);
        return new ResponseEntity<>(jobs, HttpStatus.OK);
    }

    // Find jobs by salary
    @GetMapping("/salary/{salary}")
    public ResponseEntity<List<Jobs>> findJobsBySalary(@PathVariable double salary) {
        List<Jobs> jobs = jobsService.findJobsBySalary(salary);
        return new ResponseEntity<>(jobs, HttpStatus.OK);
    }

    // Find jobs by company
    @GetMapping("/company/{company}")
    public ResponseEntity<List<Jobs>> findJobsByCompany(@PathVariable String company) {
        List<Jobs> jobs = jobsService.findJobsByCompany(company);
        return new ResponseEntity<>(jobs, HttpStatus.OK);
    }

    // Find jobs by location
    @GetMapping("/location/{location}")
    public ResponseEntity<List<Jobs>> findJobsByLocation(@PathVariable String location) {
        List<Jobs> jobs = jobsService.findJobsByLocation(location);
        return new ResponseEntity<>(jobs, HttpStatus.OK);
    }
}
