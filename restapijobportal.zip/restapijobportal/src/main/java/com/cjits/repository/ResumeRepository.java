package com.cjits.repository;

import com.cjits.entity.Resume;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ResumeRepository extends JpaRepository<Resume, Long> {

    Optional<Resume> findByJobSeekerUserIdAndResumeId(Long userId, Long resumeId);

    // Search by skills
    List<Resume> findBySkills(String skills);

    // Search by qualifications
    List<Resume> findByQualifications(String qualifications);

    // Search by achievements
    List<Resume> findByAchievements(String achievements);
}