package com.cjits.service;

import com.cjits.entity.Jobs;

import java.util.List;
import java.util.Optional;

public interface JobsService {
    Jobs saveJob(Jobs job, Long userId);
    List<Jobs> findAllJobsByRecruiterId(Long recruiterId);
    List<Jobs> findAllJobs();
    // Additional service methods can be added here

    List<Jobs> findJobsByTitle(String title);
    List<Jobs> findJobsBySkillset(String skillset);
    List<Jobs> findJobsBySalary(double salary);
    List<Jobs> findJobsByCompany(String company);
    List<Jobs> findJobsByLocation(String location);
}
