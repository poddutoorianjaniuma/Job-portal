package com.cjits.service;

import com.cjits.entity.Feedback;

import java.util.List;
import java.util.Optional;

public interface FeedbackService {
    Feedback saveFeedback(Feedback feedback);
    Optional<Feedback> findFeedbackById(Long id);
    List<Feedback> findAllFeedbacks();
    Feedback updateFeedback(Feedback feedback, Long id);
    void deleteFeedbackById(Long id);
    // Additional service methods can be added here
}
