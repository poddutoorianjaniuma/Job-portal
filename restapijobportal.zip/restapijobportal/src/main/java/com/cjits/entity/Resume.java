package com.cjits.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "resume")
public class Resume {

    public enum Role {
        USER, ADMIN
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "resume_id")
    private Long resumeId;

    @Column(name = "qualifications")
    private String qualifications;

    @Column(name = "experiences")
    private String experiences;

    @Column(name = "skills")
    private String skills;

    @Column(name = "achievements")
    private String achievements;

    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private Role role;

    @ManyToOne
    @JoinColumn(name = "jobseeker_id", referencedColumnName = "user_id")
    private User jobSeeker;

    // Constructors
    public Resume() {
    }

    public Resume(String qualifications, String experiences, String skills, String achievements, Role role, User jobSeeker) {
        this.qualifications = qualifications;
        this.experiences = experiences;
        this.skills = skills;
        this.achievements = achievements;
        this.role = role;
        this.jobSeeker = jobSeeker;
    }

    // Getters
    public Long getResumeId() {
        return resumeId;
    }

    public String getQualifications() {
        return qualifications;
    }

    public String getExperiences() {
        return experiences;
    }

    public String getSkills() {
        return skills;
    }

    public String getAchievements() {
        return achievements;
    }

    public Role getRole() {
        return role;
    }

    public User getJobSeeker() {
        return jobSeeker;
    }

    // Setters
    public void setResumeId(Long resumeId) {
        this.resumeId = resumeId;
    }

    public void setQualifications(String qualifications) {
        this.qualifications = qualifications;
    }

    public void setExperiences(String experiences) {
        this.experiences = experiences;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public void setAchievements(String achievements) {
        this.achievements = achievements;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public void setJobSeeker(User jobSeeker) {
        this.jobSeeker = jobSeeker;
    }

    // toString method
    @Override
    public String toString() {
        return "Resume{" +
                "resumeId=" + resumeId +
                ", qualifications='" + qualifications + '\'' +
                ", experiences='" + experiences + '\'' +
                ", skills='" + skills + '\'' +
                ", achievements='" + achievements + '\'' +
                ", role=" + role +
                ", jobSeeker=" + jobSeeker +
                '}';
    }
}