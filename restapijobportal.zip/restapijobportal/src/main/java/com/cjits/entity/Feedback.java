package com.cjits.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "feedback")
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "feedback_id")
    private Long feedbackId;

    @ManyToOne
    @JoinColumn(name = "jobseeker_id", referencedColumnName = "user_id")
    private User jobSeeker;

    private String message;

    // Constructors
    public Feedback() {
    }

    public Feedback(User jobSeeker, String message) {
        this.jobSeeker = jobSeeker;
        this.message = message;
    }

    // Getters and setters
    public Long getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(Long feedbackId) {
        this.feedbackId = feedbackId;
    }

    public User getJobSeeker() {
        return jobSeeker;
    }

    public void setJobSeeker(User jobSeeker) {
        this.jobSeeker = jobSeeker;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    // toString method
    @Override
    public String toString() {
        return "Feedback{" +
                "feedbackId=" + feedbackId +
                ", jobSeeker=" + (jobSeeker != null ? jobSeeker.getUserId() : "null") +
                ", message='" + message + '\'' +
                '}';
    }
}