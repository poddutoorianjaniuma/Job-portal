package com.cjits.service;

import com.cjits.entity.Experience;

import java.util.List;
import java.util.Optional;

public interface ExperienceService {
    Experience saveExperience(Experience experience, Long userId);


    List<Experience> findExperiencesByCompany(String company);
    List<Experience> findExperiencesByDesignation(String designation);

}