package com.cjits.repository;

import com.cjits.entity.Experience;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExperienceRepository extends JpaRepository<Experience, Long> {

    // Search by designation
    List<Experience> findByDesignation(String designation);

    // Search by company
    List<Experience> findByCompany(String company);

    // Search by both designation and company

}