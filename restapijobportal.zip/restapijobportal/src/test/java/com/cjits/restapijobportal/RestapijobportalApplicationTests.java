package com.cjits.restapijobportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapijobportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
